const COMPANYID = 'FFFF'
const TYPE01 = '01'
const TYPE03 = '03'
const TYPEFF = 'FF'
const TYPE09 = '09'


function processWatchBrodcast(data){
	data = data.toUpperCase()
	let len = data.slice(0,2)
	console.log(len);
	
	// if (data.indexOf('FFFF') != 0) {
	// 	console.log('非手表广播消息');
	// 	return
	// }
	
}
function getContent(type){
	
}


export default{
	processWatchBrodcast
}