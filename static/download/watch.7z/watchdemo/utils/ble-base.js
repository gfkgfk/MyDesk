/**
 * 蓝牙接口Base层
 */
import constants from './constants.js'

const TAG = 'ble-base'
/**
 * 初始化蓝牙模块
 */
function initBLE(success, fail) {
	uni.openBluetoothAdapter({
		success: e => {
			console.log(TAG, "initBLE", "初始化蓝牙成功" + JSON.stringify(e));
			success(e)
		},
		fail: e => {
			console.log(TAG, "initBLE", '初始化蓝牙失败，错误码：' + (e.errCode || e.errMsg));
			if (e.errCode !== 0) {
				bleErrorlog(e.errCode, e.errMsg);
			}
			fail(e)
		}
	});
}


/**
 * 开始搜索蓝牙设备
 */
function startBluetoothDevicesDiscovery(repeat, successFunc, failFunc, ) {
	uni.startBluetoothDevicesDiscovery({
		allowDuplicatesKey: repeat,
		success: e => {
			console.log(TAG, "startBluetoothDevicesDiscovery:success", "开始搜索蓝牙设备" + e.errMsg);
			successFunc(e)
		},
		fail: e => {
			console.log(TAG, "startBluetoothDevicesDiscovery:fail", "搜索蓝牙设备失败，错误码：" + e.errCode);
			if (e.errCode !== 0) {
				bleErrorlog(e.errCode, e.errMsg);
			}
			failFunc(e)
		}
	});
}


/**
 * 发现外围设备
 */
function onBluetoothDeviceFound(callback) {
	console.log(TAG, "onBluetoothDeviceFound");
	uni.onBluetoothDeviceFound(devices => {
		for (let i = 0; i < devices.devices.length; i++) {
			if (devices.devices[i].name) {
				console.log(TAG, "onBluetoothDeviceFound", JSON.stringify(devices));
				callback(devices.devices)
			}
		}
		// console.log(TAG, "onBluetoothDeviceFound", JSON.stringify(devices));
		//设置1秒延迟任务，只执行最后一次，因为在设备太多情况下会触发多次getBluetoothDevices
		// task = setTimeout(function() {
		// 	getBluetoothDevices();
		// }, 1000);
		// if (null != lastTask) {
		// 	clearTimeout(lastTask);
		// 	lastTask = task;
		// } else {
		// 	lastTask = task;
		// }


	});
}


/**
 * 获取在蓝牙模块生效期间所有已发现的蓝牙设备。包括已经和本机处于连接状态的设备。
 */
function getBluetoothDevices(callback) {
	uni.getBluetoothDevices({
		success: res => {
			console.log(TAG, "getBluetoothDevices:success" + '获取蓝牙设备成功:' + JSON.stringify(res));
			callback(res.devices)
		},
		fail: e => {
			console.log(TAG, "getBluetoothDevices:fail" + '获取蓝牙设备错误，错误码：' + e.errCode);
			if (e.errCode !== 0) {
				bleErrorlog(e.errCode, e.errMsg);
			}
		}
	});
}



/**
 * 连接低功耗蓝牙
 */
function createBLEConnection(deviceId, successFunc, failFunc, timeout) {
	uni.createBLEConnection({
		// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
		deviceId,
		timeout,
		success: res => {
			successFunc(res)
			console.log(TAG, "createBLEConnection:success" + '连接蓝牙成功:' + JSON.stringify(res));
			// 连接设备后断开搜索 并且不能搜索设备
			// stopBluetoothDevicesDiscovery();
			// BLESuccessNotify(currentDevice);
		},
		fail: e => {
			console.log(TAG, '连接低功耗蓝牙失败，错误码：' + e.errCode + e.errMsg);
			failFunc(e)
			if (e.errCode !== 0) {
				bleErrorlog(e.errCode, e.errMsg);
			}
			// BLEFailNotify(e);
		}
	});
}

/**
 * 停止搜索蓝牙设备
 * 已经找到需要的蓝牙设备并不需要继续搜索时，应调用该接口停止蓝牙搜索
 */
function stopBluetoothDevicesDiscovery(successFunc, failFunc) {
	uni.stopBluetoothDevicesDiscovery({
		success: e => {
			console.log(TAG, "stopBluetoothDevicesDiscovery:success", "停止搜索蓝牙设备:" + e.errMsg);
			successFunc(e)
		},
		fail: e => {
			console.log(TAG, "stopBluetoothDevicesDiscovery:fail", '停止搜索蓝牙设备失败，错误码：' + e.errCode);
			failFunc(e)
			if (e.errCode !== 0) {
				bleErrorlog(e.errCode, e.errMsg);
			}
		}
	});
}



/**
 * 断开与低功耗蓝牙设备的连接
 */
function closeBLEConnection(deviceId, successFunc, failFunc) {
	//console.log('closeBLEConnection:' + "currentBLEDeviceId:" + currentBLEDeviceId);
	uni.closeBLEConnection({
		deviceId,
		success: res => {
			console.log(TAG, '断开低功耗蓝牙成功:' + res.errMsg);
			successFunc(res)
		},
		fail: e => {
			console.log(TAG, '断开低功耗蓝牙失败，错误码：' + e.errCode);
			failFunc(e)
			if (e.errCode !== 0) {
				bleErrorlog(e.errCode, e.errMsg);
			}
		}
	});
}



/**
 * 获取所有服务
 */
function getBLEDeviceServices(deviceId, successFunc, failFunc) {
	console.log(TAG, "getBLEDeviceServices", '设备id:' + deviceId);
	uni.getBLEDeviceServices({
		// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
		deviceId,
		success: res => {
			console.log(TAG, "getBLEDeviceServices:success", JSON.stringify(res));
			successFunc(res)
			let list = res.services;
			if (list.length <= 0) {
				console.log(TAG, "getBLEDeviceServices:success", "获取设备服务失败-无服务数据");
				return
			}
		},
		fail: e => {
			console.log(TAG, "getBLEDeviceServices:fail", '获取设备服务失败，错误码：' + e.errCode);
			failFunc(e)
			if (e.errCode !== 0) {
				bleErrorlog(e.errCode, e.errMsg);
			}
		}
	});
}


/**
 * 获取某个服务下的所有特征值
 */
function getBLEDeviceCharacteristics(deviceId, serviceId, successFunc, failFunc) {
	uni.getBLEDeviceCharacteristics({
		// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
		deviceId,
		// 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
		serviceId,
		success: res => {
			successFunc(res)
			console.log(TAG, "getBLEDeviceCharacteristics:success", JSON.stringify(res));
			if (res.characteristics.length <= 0) {
				console.log(TAG, "getBLEDeviceCharacteristics:success", "获取设备特征值失败-无特征值数据");
				return;
			}
		},
		fail: e => {
			console.log(TAG, "getBLEDeviceServices:fail", '获取设备特征值失败，错误码：' + e.errCode);
			failFunc(e)
			if (e.errCode !== 0) {
				bleErrorlog(e.errCode, e.errMsg);
			}
		}
	});
}

/**
 * 断开蓝牙模块
 * @param {Object} successFunc (非必填)
 * @param {Object} failFunc (非必填)
 */
function closeBluetoothAdapter(successFunc, failFunc) {
	uni.closeBluetoothAdapter({
		success: res => {
			console.log(TAG, 'closeBluetoothAdapter', "断开蓝牙模块成功");
			if (successFunc) {
				successFunc(res)
			}
		},
		fail: e => {
			console.log(TAG, "closeBluetoothAdapter:fail", '断开蓝牙模块成功失败，错误码：' + e.errCode);
			if (failFunc) {
				failFunc(e)
			}
			if (e.errCode !== 0) {
				bleErrorlog(e.errCode, e.errMsg);
			}
		}
	});
}


/**
 * 启用低功耗蓝牙设备特征值变化时的 notify 功能，
 * 必须先启用 notifyBLECharacteristicValueChange 才能监听到设备 characteristicValueChange 事件
 */
function notifyBLECharacteristicValueChange(deviceId, serviceId, characteristicId, successFunc, failFunc) {
	console.log(TAG, "notifyBLECharacteristicValueChange", "deviceId:" + deviceId + " serviceId:" + serviceId +
		" characteristicId:" + characteristicId);
	uni.notifyBLECharacteristicValueChange({
		state: true, // 启用 notify 功能
		// 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
		deviceId,
		// 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
		serviceId,
		// 这里的 characteristicId 需要在 getBLEDeviceCharacteristics 接口中获取
		characteristicId,
		success: res => {
			successFunc(res)
			console.log(TAG, 'notifyBLECharacteristicValueChange success:' + JSON.stringify(res));
		},
		fail: e => {
			failFunc(e)
			console.log(TAG, 'notifyBLECharacteristicValueChange fail:' + JSON.stringify(e));
			bleErrorlog(e.errCode, e.errMsg);
		}
	});
}


/**
 * 监听低功耗蓝牙设备的特征值变化事件。必须先启用 notifyBLECharacteristicValueChange 接口才能接收到设备推送的 notification。
 * @param {Object} changeNotifyFunc
 */
function onBLECharacteristicValueChange(changeNotifyFunc) {
	// 必须在这里的回调才能获取
	uni.onBLECharacteristicValueChange(characteristic => {
		console.log(TAG, 'onBLECharacteristicValueChange' + "特征值变化" + JSON.stringify(characteristic));
		// let value = ab2hex(characteristic.value);
		// console.log("value:" + ab2hex(characteristic.value));
		changeNotifyFunc(characteristic);
	});
}

function writeBLECharacteristicValue(deviceId, serviceId, characteristicId, buffer, successFunc, failFunc) {
	uni.writeBLECharacteristicValue({
		deviceId: deviceId,
		serviceId: serviceId,
		characteristicId: characteristicId,
		value: buffer,
		success: res => {
			console.log(TAG, '写入成功:', JSON.stringify(res));
			successFunc(res)
		},
		fail: e => {
			console.log(TAG, '写入失败:', JSON.stringify(e));
			failFunc(e)
			bleErrorlog(e.errCode, e.errMsg);
		}
	})
}

/**
 * 监听蓝牙连接断开变化
 * 注意:如果其他地方调用后，该功能将失效
 */
function onBleStatusChange(callback) {
	uni.onBLEConnectionStateChange(res => {
		callback(res)
	})
}


function bleErrorlog(code, errMsg) {
	switch (code) {
		case constants.BLE_ERROR_CODE_NEGATIVE_1:
			console.log(TAG, '设备已连接');
			break;
		case constants.BLE_ERROR_CODE_10000:
			console.log(TAG, '未初始化蓝牙适配器');
			break;
		case constants.BLE_ERROR_CODE_10001:
			console.log(TAG, '未检测到蓝牙，请打开蓝牙重试！');
			break;
		case constants.BLE_ERROR_CODE_10002:
			console.log(TAG, '没有找到指定设备');
			break;
		case constants.BLE_ERROR_CODE_10003:
			console.log(TAG, '连接失败');
			break;
		case constants.BLE_ERROR_CODE_10004:
			console.log(TAG, '没有找到指定服务');
			break;
		case constants.BLE_ERROR_CODE_10005:
			console.log(TAG, '没有找到指定特征值');
			break;
		case constants.BLE_ERROR_CODE_10006:
			console.log(TAG, '当前连接已断开');
			break;
		case constants.BLE_ERROR_CODE_10007:
			console.log(TAG, '当前特征值不支持此操作');
			break;
		case constants.BLE_ERROR_CODE_10008:
			console.log(TAG, '其余所有系统上报的异常');
			break;
		case constants.BLE_ERROR_CODE_10009:
			console.log(TAG, 'Android 系统特有，系统版本低于 4.3 不支持 BLE');
			break;
		case constants.BLE_ERROR_CODE_10012:
			console.log(TAG, '操作超时失败！');
			break;
		default:
			console.log(TAG, errMsg);
	}
}




export default {
	initBLE,
	startBluetoothDevicesDiscovery,
	onBluetoothDeviceFound,
	getBluetoothDevices,
	createBLEConnection,
	stopBluetoothDevicesDiscovery,
	closeBLEConnection,
	getBLEDeviceServices,
	getBLEDeviceCharacteristics,
	closeBluetoothAdapter,
	notifyBLECharacteristicValueChange,
	onBLECharacteristicValueChange,
	onBleStatusChange,
	writeBLECharacteristicValue
}
