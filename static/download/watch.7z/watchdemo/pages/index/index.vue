<template>
	<view>
		<view>watch小程序获取数据演示demo</view>
		<scroll-view :scroll-y="true" class="info">
			{{info}}
		</scroll-view>
		<view class="content">
			<view class="btn" @click="initBLEadapter()">初始化</view>
			<view class="btn" @click="searchDevices()">开始搜索</view>
			<view class="btn" @click="stopSearch()">停止搜索</view>
			<view class="btn" @click="test()">测试按钮</view>
			<view class="btn" @click="closeBLEAdapter()">关闭适配器</view>
		</view>
	</view>

</template>

<script>
	import ble from '@/utils/ble-base-wrapper.js'
	import watch from '@/utils/device-protocol/watch.js'
	import parseUtil from '@/utils/parse-tool-utils.js'
	export default {
		data() {
			return {
				bleName: 'GTR1-614C',
				title: 'Hello',
				deviceId: '',
				info: '返回结果'
			}
		},
		onLoad() {},
		beforeDestroy() {
			this.closeBLEAdapter()
		},
		methods: {
			initBLEadapter() {
				ble.initBLE(success => {
					this.info = "初始化蓝牙成功"
					console.log('初始化成功');
				}, error => {
					console.log('初始化蓝牙失败');
				})
			},
			searchDevices() {
				ble.startBLEDiscoveryByName(this.bleName, true, success => {
					this.info = JSON.stringify(success)
				}, error => {
					this.info = JSON.stringify(success)
				}, callback => {
					this.info = JSON.stringify(callback)
					console.log('发现设备:' + JSON.stringify(callback));
					let data =parseUtil.ab2hex(callback.advertisData)
					console.log('deviceId:'+callback.deviceId+' 广播数据:'+data);
					let temp = '020106030300FF0EFFFFFFFAC578EF2923FF00002B0E08094B482D32393233'
					watch.processWatchBrodcast(temp)
					//发现设备后停止搜索
					//this.stopSearch()
				})
			},
			stopSearch() {
				ble.stopBluetoothDevicesDiscovery(success => {
					this.info = '停止搜索成功:' + JSON.stringify(success)
				}, error => {
					this.info = '停止搜索失败:' + JSON.stringify(error)
				})
			},
			closeBLEAdapter() {
				ble.closeBluetoothAdapter(success => {
					this.info = '关闭蓝牙模块成功:' + JSON.stringify(success)
				}, error => {
					this.info = '关闭蓝牙模块失败:' + JSON.stringify(error)
				})
			},
			test() {
				let temp = '020106030300FF0EFFFFFFFAC578EF2923FF00002B0E08094B482D32393233'
				watch.processWatchBrodcast(temp)
				
				
				// ble.getBluetoothDevices(success => {
				// 	console.log('设备列表：' + JSON.stringify(success));
				// }, error => {
				// 	console.log('设备列表：错误');
				// })
			},
			navTo(url) {
				uni.navigateTo({
					url: url
				})
			}


		}
	}
</script>

<style lang="scss">
	.title {
		width: 100%;
	}

	.info {
		color: grey;
		word-wrap: break-word;
		border: 1rpx solid;
		height: 300rpx;
		width: 100%;
	}

	.content {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		margin-left: 30rpx;
		margin-right: 30rpx;

		.btn {
			margin-top: 40rpx;
			border: 1rpx solid;
			width: 300rpx;
			border-radius: 20rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			height: 80rpx;
		}

	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
