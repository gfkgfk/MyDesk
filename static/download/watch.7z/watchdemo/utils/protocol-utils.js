/**
 * 16进制转换为字符串
 * @param hex
 * @returns {*}
 */
function hexToString(hex) {
	var tmp = '';
	if (hex.length % 2 == 0 ) {
		for (var i = 0; i < hex.length; i += 2) {
			let tempStr = hex.charAt(i) + hex.charAt(i + 1);
			if(tempStr!='00'){
				tmp += '%' + tempStr;
			}
		}
	}
	return decodeURIComponent(tmp);
}

/**
 * 字符串转16进制
 * @param str
 * @returns {string}
 */
function stringToHex(str) {
	var hex = "";
	for (var i = 0; i < str.length; i++) {
		hex += str.charCodeAt(i).toString(16);
	}
	return hex;
}




/**
 * 16进制字符串转数组
 */
function hexStrToArray(hexStr){
	let reg=/.{2}/g;
	let rs=hexStr.match(reg);//注意如果s的长度小于2,那么rs=null
	return rs
}

/**
 * 字符串数组转字符串
 * @param {Object} array
 */
function ArrayToStr(array){
	return array.join('')
}


/**
 * ArrayBuffer转16进度字符串示例
 * @param {Object} buffer
 */
function ab2hex(buffer) {
	const hexArr = Array.prototype.map.call(
		new Uint8Array(buffer),
		function(bit) {
			return ('00' + bit.toString(16)).slice(-2)
		}
	)
	return hexArr.join('')
}


/**
 * 16进度字符串转ArrayBuffer示例
 * @param {Object} buffer
 */
function hex2ab(hex) {

	var typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function(h) {
		return parseInt(h, 16)
	}));

	var buffer = typedArray.buffer;
	return buffer;
}


/**
 * 二进制字符串填充0
 */
function binaryStrToStr(binary) {
	let len = binary.length;
	for (var i = 0; i < (8 - len); i++) {
		binary = "0" + binary;
	}
	return binary;
}

/**
 * 获取16进制字符串中剔除0x部分的值
 * @param {Object} str
 */
function getHEXValStr(str) {
	if (typeof(str) != 'string') {
		return;
	}
	if ("0x" != str.substring(0, 2)) {
		return
	}
	return str.substring(2, str.length);

}



/**
 * 16进制转10进制
 * // 15 + 16 * 13 + 256 = 479
 * //log.debug(hex2int("1df"));
 * @param {Object} hex
 */
function hex2int(hex) {
	var len = hex.length,
		a = new Array(len),
		code;
	for (var i = 0; i < len; i++) {
		code = hex.charCodeAt(i);
		if (48 <= code && code < 58) {
			code -= 48;
		} else {
			code = (code & 0xdf) - 65 + 10;
		}
		a[i] = code;
	}

	return a.reduce(function(acc, c) {
		acc = 16 * acc + c;
		return acc;
	}, 0);
}

/**
 * 10进制转16进制
 * eg 
 * log.debug(int2hex(479, 8));
 * 0x000001df
 * 
 * @param {Object} num
 * @param {Object} width
 */
function int2hex(num, width) {
	var hex = "0123456789abcdef";
	var s = "";
	while (num) {
		s = hex.charAt(num % 16) + s;
		num = Math.floor(num / 16);
	}
	if (typeof width === "undefined" || width <= s.length) {
		return "0x" + s;
	}
	var delta = width - s.length;
	var padding = "";
	while (delta-- > 0) {
		padding += "0";
	}
	return "0x" + padding + s;
}

/**
* 数字位数不够，进行前补零
* @param num： 被操作数
* @param n： 固定的总位数
*/
function PrefixZero(num, n) {
    return (Array(n).join(0) + num).slice(-n);
}



//将文字转换为16进制
function textToSix(str) {
	return escape(str).replace(/%/g, function() {
		return "\\";
	}).toLowerCase();
}

//将16进制表示为文字
function sixToText(str) {
	return unescape(str);
}

export default {
	hexToString,
	stringToHex,
	hexStrToArray,
	ArrayToStr,
	ab2hex,
	hex2ab,
	binaryStrToStr,
	getHEXValStr,
	hex2int,
	int2hex,
	PrefixZero,
	textToSix,
	sixToText
}