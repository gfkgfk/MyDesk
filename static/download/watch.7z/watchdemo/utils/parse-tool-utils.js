
/**
 * ArrayBuffer转16进度字符串示例
 * @param {Object} buffer
 */
function ab2hex(buffer) {
	const hexArr = Array.prototype.map.call(
		new Uint8Array(buffer),
		function(bit) {
			return ('00' + bit.toString(16)).slice(-2)
		}
	)
	return hexArr.join('')
}


/**
 * 16进度字符串转ArrayBuffer示例
 * @param {Object} buffer
 */
function hex2ab(hex) {

	var typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function(h) {
		return parseInt(h, 16)
	}));

	var buffer = typedArray.buffer;
	return buffer;
}


export default{
	ab2hex,
	hex2ab
}



