import base from './ble-base.js'
const TAG = 'ble-base-wrapper'


/**
 * 初始化蓝牙适配器
 * @param {Object} success
 * @param {Object} fail
 */
function initBLE(success, fail) {
	base.initBLE(success, fail)
}

/**
 * 开启BLE蓝牙搜索功能
 * @param {Object} successFunc
 * @param {Object} failFunc
 */
function startBluetoothDevicesDiscovery(repeat,successFunc, failFunc) {
	base.startBluetoothDevicesDiscovery(repeat,success => {
		successFunc(success)
	}, fail => {
		failFunc(fail)
	})
}

/**
 * 发现设备时上报
 * (确保onBluetoothDeviceFound先调用)
 * @param {Object} successFunc
 * @param {Object} failFunc
 * @param {Object} callback 搜索到设备的回调
 */
function startBLEDiscovery(repeat,successFunc, failFunc, callback) {
	//先开启发现外围设备
	base.onBluetoothDeviceFound(callback);
	//再开启搜索
	base.startBluetoothDevicesDiscovery(repeat,success => {
		successFunc(success)
	}, fail => {
		failFunc(fail)
	})
}

/**
 * 发现指定设备名称时上报
 * (确保onBluetoothDeviceFound先调用)
 * @param {Object} successFunc
 * @param {Object} failFunc
 * @param {Object} callback 搜索到设备的回调
 */
function startBLEDiscoveryByName(bleName,repeat, successFunc, failFunc, callback) {
	//先开启发现外围设备
	base.onBluetoothDeviceFound(device => {
		for (let i = 0; i < device.length; i++) {
			if (device[i].name.indexOf(bleName) == 0) {
				callback(device[i])
			}
		}
	});
	//再开启搜索
	base.startBluetoothDevicesDiscovery(repeat,success => {
		successFunc(success)
	}, fail => {
		failFunc(fail)
	})
}

/**
 * 发现指定设备id时上报
 * (确保onBluetoothDeviceFound先调用)
 * @param {Object} successFunc
 * @param {Object} failFunc
 * @param {Object} callback 搜索到设备的回调
 */
function startBLEDiscoveryByDeviceId(deviceId, repeat,successFunc, failFunc, callback) {
	//先开启发现外围设备
	base.onBluetoothDeviceFound(device => {
		for (let i = 0; i < device.length; i++) {
			if (device[i].deviceId == deviceId) {
				callback(device)
			}
		}
	});
	//再开启搜索
	base.startBluetoothDevicesDiscovery(repeat,success => {
		successFunc(success)
	}, fail => {
		failFunc(fail)
	})
}

/**
 * 开启发现外围设备功能
 * @param {Object} callback
 */
function onBluetoothDeviceFound(callback) {
	base.onBluetoothDeviceFound(callback)
}

/**
 * 获取在蓝牙模块生效期间所有已发现的蓝牙设备。包括已经和本机处于连接状态的设备。
 * @param {Object} callback
 */
function getBluetoothDevices(callback) {
	base.getBluetoothDevices(callback)
}

function createBLEConnection(deviceId, successFunc, failFunc, timeout = 6000) {
	//带上连接成功的deviceId
	base.createBLEConnection(deviceId, success => {
		success.deviceId = deviceId
		successFunc(success)
	}, fail => {
		fail.deviceId = deviceId
		failFunc(fail)
	}, timeout)
}



function stopBluetoothDevicesDiscovery(success, fail) {
	base.stopBluetoothDevicesDiscovery(success, fail)
}

function closeBLEConnection(deviceId, success, fail) {
	base.closeBLEConnection(deviceId, success, fail)
}

function getBLEDeviceServices(deviceId, successFunc, failFunc) {
	base.getBLEDeviceServices(deviceId, successFunc, failFunc)
}

function getBLEDeviceCharacteristics(deviceId, serviceId, successFunc, failFunc) {
	base.getBLEDeviceCharacteristics(deviceId, serviceId, successFunc, failFunc)
}

/**
 * 断开蓝牙模块
 * @param {Object} successFunc (非必填)
 * @param {Object} failFunc (非必填)
 */
function closeBluetoothAdapter(successFunc, failFunc) {
	base.closeBluetoothAdapter(successFunc, failFunc)
}

function notifyBLECharacteristicValueChange(deviceId, serviceId, characteristicId, successFunc, failFunc) {
	base.notifyBLECharacteristicValueChange(deviceId, serviceId, characteristicId, successFunc, failFunc)
}

function onBLECharacteristicValueChange(changeNotifyFunc) {
	base.onBLECharacteristicValueChange(changeNotifyFunc)
}

function writeBLECharacteristicValue(deviceId, serviceId, characteristicId, buffer, successFunc, failFunc){
	base.writeBLECharacteristicValue(deviceId, serviceId, characteristicId, buffer, successFunc, failFunc)
}


export default {
	initBLE,
	startBluetoothDevicesDiscovery,
	startBLEDiscovery,
	startBLEDiscoveryByName,
	startBLEDiscoveryByDeviceId,
	onBluetoothDeviceFound,
	getBluetoothDevices,
	createBLEConnection,
	stopBluetoothDevicesDiscovery,
	closeBLEConnection,
	getBLEDeviceServices,
	getBLEDeviceCharacteristics,
	closeBluetoothAdapter,
	notifyBLECharacteristicValueChange,
	onBLECharacteristicValueChange,
	writeBLECharacteristicValue
}
